package com.spring.boot;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/students")
public class StudentController {
	
	private static List<Student> list  = new ArrayList<Student>();

	@RequestMapping("/greeting")
	public String greeting(@RequestParam(value = "name", defaultValue = "World") String name) {
		return "inside controller";
	}
	
	@RequestMapping(value ="/view" , method = RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Student> view() {
		return list;
	}
	
	@RequestMapping(value ="/delete/{id}" , method = RequestMethod.DELETE,produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Student> delete(@PathVariable(name="id") Integer id) {
		System.out.println(id);
		Student student = new Student();
		for (Student std : list){
			if(std.getId()==id){
				student = std;
				break;
			}			
		}
		
		if(!ObjectUtils.isEmpty(student)){
			System.out.println("Student Removed" + student);
			list.remove(student);
		}
		return list;
	}
	
	@RequestMapping(value ="/update/{id}" , method = RequestMethod.PUT,produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Student> update(@RequestBody Student newStudent,@PathVariable(name="id") Integer id) {
		System.out.println(id);
		Student student1 = new Student();
		for (Student std : list){
			if(std.getId()==id){
				std.setAge(newStudent.getAge());				
				std.setName(newStudent.getName());	
				break;
			}			
		}
		
		
		return list;
	}
	
	@RequestMapping(value ="/save" , method = RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE)
	public void save(@RequestBody Student student) {	
		System.out.println("In save method");
		list.add(student);		
	}
	
	 @RequestMapping("/home")
	 public String home() {
	  return "index.html";
	 }

}
