var mainApp = angular.module("myApp", ['ngRoute']);

mainApp.controller('myController',['$scope','$location','AddStudentService',function($scope,$location,AddStudentService){

$scope.student = {name:'',age:null,id:null};

 $scope.sliderValue = 10;
 
$scope.submitDetails=  function(){

     AddStudentService.createStudent($scope.student).then(
        function(data){
            console.log('success');
        },
        function(errorRes){
            console.error('error');
        });
        $scope.reset(); 

 };
 $scope.reset= function(){
	$scope.student = {name:'',age:null,id:null};
	$scope.studentForm.$setPristine();
 };
 
 $scope.refresh = function(){
   AddStudentService.getData().then(
        function(data){
        	console.log(data);
        	 $scope.students=data;
            console.log('success');
        },
        function(errorRes){
            console.error('error');
        });
 };

$scope.refresh();

 
 $scope.deleteStudent = function(std){
  $scope.student = std;
  AddStudentService.deleteStudent($scope.student.id).then(
	        function(data){
	        	console.log(data);
	        	 $scope.students=data;
	            console.log('success');
	        },
	        function(errorRes){
	            console.error('error');
	        });
 };
 
 $scope.message = "";
 
 $scope.update = function(std){
	$scope.student = std;

	AddStudentService.update($scope.student).then(
	        function(data){
	        	console.log(data);
	        	 $scope.students=data;
	            console.log('success');
	        },
	        function(errorRes){
	            console.error('error');
	        });
 };
 
}]);


mainApp.service('AddStudentService',['$http','$q','$location',function($http,$q,$location){
	

	$http.defaults.headers.post["Content-Type"] = "application/json";

	this.createStudent =  function(student){
		var defered  = $q.defer();
		$http.post('/students/save', student)
		.then(function(response){
			defered.resolve(response.data);
		},
		function(errResp){
			console.error('error while creating');
			defered.reject(errResp);
		}		
	 );	 
	 return defered.promise;
	}	
	
	 this.getData = function() {
	 	var defered  = $q.defer();
        $http.get('/students/view')
        .then(function(response) {           
			defered.resolve(response.data);	
        }, function(x) {
			console.error('error while gettting creating');	
			defered.reject(errResp);		
        });
        return defered.promise;
   }
   
   this.deleteStudent = function(id){
   	var defered  = $q.defer();
	    $http.delete('/students/delete/'+id)		
        .then(function(response) { 	
			console.log('deleted success'); 		
			defered.resolve(response.data);			
        }, function(x) {
			console.error('error while deleting');			
        });
		return defered.promise;
   }
   
	this.update =  function(student){
		var defered  = $q.defer();
		$http.put('/students/update/'+student.id, student)
		.then(function(response){
			console.log('update success'); 		
			defered.resolve(response.data);
		},
		function(errResp){
			console.error('error while updating');
		}		
	 );	 
	 return defered.promise;
	}
   
  
}]);

mainApp.directive('jqSlider', [function() {

  return {
    restrict: 'A',
    scope: {
      'model': '='
    },
    link: function(scope, elem, attrs) {
      $(elem).slider({
        value: +scope.model,
        slide: function(event, ui) {
          scope.$apply(function() {
            scope.model = ui.value;
          });
        }
      });
      // Watch for changes to the model and update the slider
      scope.$watch('model', function(newVal) {
        $slider.slider('value', newVal);
      });
    }
  };
}]);


mainApp.config(['$routeProvider','$locationProvider',function($routeProvider,$locationProvider){
	$routeProvider
		.when('/home',{
			templateUrl:'client/home.html',
			controller:'myController',
			controllerAs:'stud'
		
		})
		.when('/students',{
			templateUrl:'client/students.html',
			controller:'myController',
			controllerAs:'stud'
		
		})	
		.when('/update',{
			templateUrl:'client/update.html',
			controller:'myController',
			controllerAs:'stud'
		
		})	
		.when('/viewSlider',{
        templateUrl:'client/slider.html',
        controller:'myController',
        controllerAs:'stud'
    	})	
		.when('/viewStudents',{
			templateUrl:'client/view.html',
			controller:'myController',
			controllerAs:'stud'
		
		})
		.otherwise({
			redirectTo:'/home'
		});	
	$locationProvider.html5Mode(true);
		
}]);

