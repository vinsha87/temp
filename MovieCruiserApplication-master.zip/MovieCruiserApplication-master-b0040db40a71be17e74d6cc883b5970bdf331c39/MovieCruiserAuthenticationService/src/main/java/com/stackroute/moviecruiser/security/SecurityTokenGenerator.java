package com.stackroute.moviecruiser.security;

import java.util.Map;

import com.stackroute.moviecruiser.domain.User;

public interface SecurityTokenGenerator {
	Map<String, String> generateToken(User user);
}
