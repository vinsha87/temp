package com.stackroute.moviecruiserserverapplication.exception;

public  class MovieNotfoundException extends Exception{
	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "MovieNotfoundException [message=" + message + "]";
	}

	public MovieNotfoundException(String message) {
		super();
		this.message=message;
	}
	
	public MovieNotfoundException() {
		super();
		
	}
	
}
