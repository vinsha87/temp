package com.stackroute.moviecruiserserverapplication.exception;

public class MovieExistException extends Exception{

	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "MovieExistException [message=" + message + "]";
	}

	public MovieExistException(String message) {
		super();
		this.message=message;
	}

	
}
