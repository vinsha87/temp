package com.stackroute.moviecruiserserverapplication.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.moviecruiserserverapplication.domain.Movie;
import com.stackroute.moviecruiserserverapplication.exception.MovieExistException;
import com.stackroute.moviecruiserserverapplication.exception.MovieNotfoundException;
import com.stackroute.moviecruiserserverapplication.repo.MovieRepo;
import com.stackroute.moviecruiserserverapplication.service.MovieService;

@Service("movieService")
public class MovieServiceImpl implements MovieService {

	@Autowired
	private final MovieRepo movieRepo;

	public MovieServiceImpl(final MovieRepo movieRepo) {
		super();
		this.movieRepo = movieRepo;
	}

	@Override
	public boolean saveMovie(Movie movie) throws MovieExistException {
		Optional<Movie> movieObj = movieRepo.findById(movie.getId());
		if (movieObj.isPresent()) {
			throw new MovieExistException("Movie already exist");
		} else {
			movieRepo.save(movie);
			return true;
		}

	}

	@Override
	public Movie updateMovie(Movie movie) throws MovieNotfoundException {
		Movie movieObj = movieRepo.findById(movie.getId()).orElse(null);
		if (movieObj != null) {
			movieObj.setComments(movie.getComments());
			movieRepo.save(movie);
		} else {
			throw new MovieNotfoundException("Movie not found");
		}
		return movieObj;
	}

	@Override
	public boolean deleteMovie(int id) throws MovieNotfoundException {
		Movie movieObj = movieRepo.findById(id).orElse(null);
		if (movieObj == null) {
			throw new MovieNotfoundException("Movie not found");
		} else {
			movieRepo.delete(movieObj);
		}
		return true;
	}

	@Override
	public List<Movie> getMovies() throws MovieNotfoundException {
		List<Movie> movies = movieRepo.findAll();
		return movies;
	}
	
	@Override
	public List<Movie> getMyMovies(String userId) {
		return movieRepo.findByUserId(userId);
	}

	@Override
	public Movie getmovieById(int id) throws MovieNotfoundException {
		Optional<Movie> movieObj = movieRepo.findById(id);
		if (movieObj.isPresent()) {
			return movieObj.get();
		} else {
			throw new MovieNotfoundException("Movie not found");
		}

	}

	public MovieRepo getMovieRepo() {
		return movieRepo;
	}

}
