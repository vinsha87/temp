package com.stackroute.moviecruiserserverapplication.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stackroute.moviecruiserserverapplication.domain.Movie;

public interface MovieRepo extends JpaRepository<Movie, Integer>{
	List<Movie> findByUserId(String userId);
}
