package com.stackroute.moviecruiserserverapplication.service;

import java.util.List;

import com.stackroute.moviecruiserserverapplication.domain.Movie;
import com.stackroute.moviecruiserserverapplication.exception.MovieExistException;
import com.stackroute.moviecruiserserverapplication.exception.MovieNotfoundException;

public interface MovieService {
	boolean saveMovie(Movie movie) throws MovieExistException;

	Movie updateMovie(Movie movie) throws MovieNotfoundException;

	boolean deleteMovie(int id) throws MovieNotfoundException;

	List<Movie> getMovies() throws MovieNotfoundException;

	Movie getmovieById(int id) throws MovieNotfoundException;
	
	List<Movie> getMyMovies(String userId);
}
