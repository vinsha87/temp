package com.stackroute.moviecruiserserverapplication.controller;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.stackroute.moviecruiserserverapplication.domain.Movie;
import com.stackroute.moviecruiserserverapplication.service.MovieService;

@RunWith(SpringRunner.class)
@WebMvcTest(MovieCruiserController.class)

public class MovieControllerTest {

	private MockMvc mvc;
	
	@MockBean
	private transient MovieService service;
	@InjectMocks
	private MovieCruiserController controller;
	
	private transient Movie movie;
	static List<Movie> movies;

	@Before
	public void SetUp() {
		MockitoAnnotations.initMocks(this);
		movies = new ArrayList<>();
		movie = new Movie(1,"1", "goodMovie", "POC", "ww.abc.com", "2015/03/23", "adipoli",
				45,"1");
		
		movies.add(movie);
		movie = new Movie(2,"2", "Nice Movie", "POC", "ww.bbc.com", "2018/03/23", "okke",
				55,"2");
		movies.add(movie);
		
		mvc = MockMvcBuilders.standaloneSetup(controller).build();
	}
/*
	@Test
	public void testSaveNewMovieSucess() throws Exception {
		String token = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJzcmVlcmFtIiwiaWF0IjoxNTM3MTAxOTcwfQ.ZtFMQjxX-YwVYKedwg2GGBS6WxE6Sc6eysq8rd4kJuU";
		movie.setComments("Good movie");
		when(service.saveMovie(movie)).thenReturn(true);
		mvc.perform(post("/api/movie").header("authorization", "Bearer "+token).contentType(MediaType.APPLICATION_JSON).content(jsonToString(movie)))
				.andExpect(status().isCreated());
		verify(service, times(1)).saveMovie(Mockito.any(Movie.class));
		verifyNoMoreInteractions(service);
	}*/

	@Test
	public void testUpdateMovieSucess() throws Exception {
		movie.setComments("Okke");
		when(service.updateMovie(movie)).thenReturn(movies.get(0));
		mvc.perform(put("/api/movie/{id}", 1).contentType(MediaType.APPLICATION_JSON).content(jsonToString(movie)))
				.andExpect(status().isOk());
		verify(service, times(1)).updateMovie(Mockito.any(Movie.class));
		verifyNoMoreInteractions(service);
	}

	private static String jsonToString(final Object obj) throws JsonProcessingException {
		// TODO Auto-generated method stub
		String result;
		try {
			final ObjectMapper mapper = new ObjectMapper();
			final String jsonContent = mapper.writeValueAsString(obj);
			result = jsonContent;
		} catch (JsonProcessingException e) {
			// TODO: handle exception
			result = "Json Parse error";
		}
		return result;
	}

	@Test
	public void testDeleteMovie() throws Exception {
		when(service.deleteMovie(1)).thenReturn(true);
		mvc.perform(delete("/api/movie/{id}", 1)).andExpect(status().isOk());
		verify(service, times(1)).deleteMovie(1);
		verifyNoMoreInteractions(service);
	}

	@Test
	public void testGetMovieById() throws Exception {
		when(service.getmovieById(1)).thenReturn(movies.get(0));
		mvc.perform(get("/api/movie/{id}", 1)).andExpect(status().isOk());
		verify(service, times(1)).getmovieById(1);
		verifyNoMoreInteractions(service);
	}



}
