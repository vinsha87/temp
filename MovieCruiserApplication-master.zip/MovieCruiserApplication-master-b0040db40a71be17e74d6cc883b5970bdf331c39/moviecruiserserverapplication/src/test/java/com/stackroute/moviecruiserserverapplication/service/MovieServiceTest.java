package com.stackroute.moviecruiserserverapplication.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.stackroute.moviecruiserserverapplication.domain.Movie;
import com.stackroute.moviecruiserserverapplication.exception.MovieExistException;
import com.stackroute.moviecruiserserverapplication.exception.MovieNotfoundException;
import com.stackroute.moviecruiserserverapplication.repo.MovieRepo;
import com.stackroute.moviecruiserserverapplication.serviceImpl.MovieServiceImpl;

public class MovieServiceTest {

	@Mock
	private transient MovieRepo movieRepo;
	private transient Movie movie;
	@InjectMocks
	private transient MovieServiceImpl movieServiceImpl;
	transient Optional<Movie> options;

	@Before
	public void setupMock() {
		MockitoAnnotations.initMocks(this);
		movie = new Movie(1,"1", "goodMovie", "POC", "ww.abc.com", "2015/03/23", "adipoli", 45,"1");
		options = Optional.of(movie);
	}

	@Test
	public void testMockCreation() {
		assertNotNull("jpaRepository creation fails:use @injectMocks on movieServiceImpl", movie);
	}

	/*@Test
	public void testSaveMovieOk() throws MovieExistException {
		when(movieRepo.save(movie)).thenReturn(movie);
		final boolean flag = movieServiceImpl.saveMovie(movie);
		assertTrue("saving movie ooke", flag);
		verify(movieRepo, times(1)).save(movie);
	}
*/
	@Test(expected = MovieExistException.class)
	public void testSaveMovieCheckFal() throws MovieExistException {
		when(movieRepo.findById(1)).thenReturn(options);
		when(movieRepo.save(movie)).thenReturn(movie);
		final boolean flag = movieServiceImpl.saveMovie(movie);
		assertFalse("saving movie fails", flag);
		verify(movieRepo, times(1)).findById(movie.getId());
	}

	/*@Test
	public void testUpdateMyMovie() throws MovieNotfoundException {
		when(movieRepo.findById(1)).thenReturn(options);
		when(movieRepo.save(movie)).thenReturn(movie);
		movie.setComments("not so good movie");
		final Movie movie1 = movieServiceImpl.updateMovie(movie);
		assertEquals("updating movie failed", "Not good movie", movie1.getComments());
		verify(movieRepo, times(1)).save(movie);
		verify(movieRepo, times(1)).findById(movie.getId());
	}
*/
	@Test
	public void testDeleteMovieById() throws MovieNotfoundException {
		when(movieRepo.findById(1)).thenReturn(options);
		doNothing().when(movieRepo).delete(movie);
		final boolean flag = movieServiceImpl.deleteMovie(1);
		assertTrue("deleting movie failed", flag);
		verify(movieRepo, times(1)).delete(movie);
		verify(movieRepo, times(1)).findById(movie.getId());
	}

	@Test
	public void testGetMovieById() throws MovieNotfoundException {
		when(movieRepo.findById(1)).thenReturn(options);
		final Movie movie1 = movieServiceImpl.getmovieById(1);
		assertEquals("Get movie by id failed", movie1, movie);
		verify(movieRepo, times(1)).findById(movie.getId());
	}

	

}
