import { AppPage } from './app.po';
import { browser, by, element } from 'protractor';
import { protractor } from 'protractor';

describe('movie-cruiser App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  

  it('should display title', () => {
    page.navigateTo();
    expect(browser.getTitle()).toEqual('MovieCruiser');
  });

  it('should be redirected to /login route on openning the appliacaation', () => {
    expect(browser.getCurrentUrl()).toContain('/login');
  });
  it('should be redirected to /register route', () => {
     browser.driver.sleep(1000);
    browser.element(by.css('.register-button')).click();
     expect(browser.getCurrentUrl()).toContain('/register');
   });
  it('should be able to register user', () => {
     browser.driver.sleep(1000);
     browser.element(by.id('firstName')).sendKeys('sree');
    browser.element(by.id('lastName')).sendKeys('tg');
     browser.element(by.id('userId')).sendKeys('hari');
    browser.element(by.id('password')).sendKeys('1234');
     browser.element(by.css('.register-user')).click();
     expect(browser.getCurrentUrl()).toContain('/login');
   });
  it('should be able to login user and nevigate to /movies/popular', () => {
    browser.driver.sleep(2000);
    browser.element(by.id('userId')).sendKeys('hari');
    browser.element(by.id('password')).sendKeys('1234');
    browser.element(by.css('.login-user')).click();
    expect(browser.getCurrentUrl()).toContain('/movies/popular');
    browser.driver.sleep(3000);
  });
  it('should be able to search for movies', () => {
     browser.driver.sleep(3000);
     //browser.element(by.css('.search-button')).click();
     browser.get('/movies/search');
     expect(browser.getCurrentUrl()).toContain('/movies/search');
     browser.driver.sleep(3000);
     browser.element(by.id('mat-input-0')).sendKeys('Super');
     browser.element(by.id('mat-input-0')).sendKeys(protractor.Key.ENTER);
     const searchItems = element.all(by.css('.mat-card-title'));
     expect(searchItems.count()).toBe(20);
     for(let i=0;i<1;i+=1){
      expect(searchItems.get(i).getText()).toContain('Super');
    }
    browser.driver.sleep(3000);
   });
  it('should be able to add movie in the watch list',async ()=>{
    browser.manage().window().maximize();
    browser.driver.sleep(1000);
     const searchItems = element.all(by.css('.movie-thumbnail'));
    expect(searchItems.count()).toBe(20);
     searchItems.get(0).click();
     browser.element(by.css('.mat-button')).click();
  });
  
});
