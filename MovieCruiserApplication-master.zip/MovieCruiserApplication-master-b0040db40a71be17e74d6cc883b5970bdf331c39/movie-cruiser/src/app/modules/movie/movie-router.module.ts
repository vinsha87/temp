import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ComponentComponent } from './components/component/component.component';
//import { ContainerComponent } from './components/container/container.component';
import {ThumbnailComponent } from './components/thumbnail/thumbnail.component';
import { TmdbContainerComponent } from './components/tmdb-container/tmdb-container.component';
import { SearchComponent } from './components/search/search.component';
import { WatchListComponent } from './components/watch-list/watch-list.component';
import { AuthguardService } from './../../authguard.service';
const movieRoutes : Routes = [{
    path: 'movies',
    children: [
        {
            path: '',
            redirectTo: '/movies/popular',
            pathMatch: 'full',
            canActivate: [AuthguardService]
        },
        {
            path: 'popular',
            canActivate: [AuthguardService],
            component: TmdbContainerComponent,
            data: {
                movieType: 'popular',
            }
        },
        {
            path: 'top_rated',
            canActivate: [AuthguardService],
            component: TmdbContainerComponent,
            data: {
                movieType: 'top_rated',
            }
        },
        {
            path: 'watchList',
            canActivate: [AuthguardService],
            component: WatchListComponent,
            
        },
        {
            path: 'search',
            canActivate: [AuthguardService],
            component: SearchComponent,
            
        }
    ]
}];

@NgModule({
    imports: [
        RouterModule.forRoot(movieRoutes),
    ],

    exports: [
        RouterModule
    ],
    providers: [

    ]
})
export class MovieRouterModule { }