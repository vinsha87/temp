import { Component, OnInit,Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MovieService } from '../../movie.service';
import { Movie } from '../../movie';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'movie-component',
  //template: `<img *ngFor="let movie of movies" [src]="movie?.poster_path" class="movie-container"
  //[alt]="movie?.title">`,
  templateUrl: './component.component.html',
  styleUrls: ['./component.component.css']
})
export class ComponentComponent implements OnInit {
  @Input()
  movies: Array<Movie>;

  @Input()
  usewatchListapi:boolean;
 
  constructor(private movieService:MovieService,private snackbar:MatSnackBar) {
   
   }

  ngOnInit() {
   
  }
  addMovieTowatchList(movie:Movie)
  {   let message=`${movie.title} Added to watch list`;
      this.movieService.addMoviesToWatchList(movie).subscribe((movie) =>{
       
        console.log(movie)
     this.snackbar.open(message,'',{duration:1000});
     });
  }
  deleteMovieFromWatchList(movie:Movie)
  {
    let message=`${movie.id} Deleted from watch list`;
    console.log(message);
     for(var i=0;i<this.movies.length;i++)
     {
     
      if(this.movies[i].id==movie.id)
      {
            
       console.log("movie deleted"+this.movies[i].title)
          this.movies.splice(i,1);
      }
     }
    
     this.movieService.deleteMovieFromwatchList(movie).subscribe((movie)=>{
      this.snackbar.open(message,'',{duration:1000});
     })
     
  }

}
