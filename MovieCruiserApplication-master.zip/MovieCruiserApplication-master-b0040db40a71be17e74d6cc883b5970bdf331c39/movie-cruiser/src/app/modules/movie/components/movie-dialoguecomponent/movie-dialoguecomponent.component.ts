import { Component, OnInit,Input,Inject } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import {MatDialog,MatDialogRef,MAT_DIALOG_DATA} from '@angular/material'
import { Movie } from '../../movie';
import { MovieService } from '../../movie.service';


@Component({
  selector: 'app-movie-dialoguecomponent',
  templateUrl: './movie-dialoguecomponent.component.html',
  styleUrls: ['./movie-dialoguecomponent.component.css']
})
export class MovieDialoguecomponentComponent implements OnInit {

   movie:Movie;
   comments:string;
   actiontype:string

  constructor(public snackBar:MatSnackBar,public dialogRef:MatDialogRef<MovieDialoguecomponentComponent>,
    @Inject(MAT_DIALOG_DATA) public data:any,private movieservice :MovieService)
     {
        this.movie=data.obj;
        this.comments=data.obj.movieComments;
        this.actiontype=data.actiontype;


      }

  ngOnInit() {

    console.log(this.data);
  }
  cancel()
  {
    this.dialogRef.close();
  }

  update()
  {
    console.log(this.comments);
    this.movie.comments=this.comments
    this.dialogRef.close();
    this.movieservice.updateMovieFromwatchList(this.movie).subscribe(movie =>{

      this.snackBar.open('Movie Updated In watchList successfully','',{duration:1000});
   
    })

  }

}
