
import { Component, OnInit, Input,Output,EventEmitter} from '@angular/core';
import { Movie } from '../../movie';
import { MovieService } from '../../movie.service';
import { MatCardModule } from '@angular/material';
import { MatSnackBar } from '@angular/material/snack-bar';
import {MatDialog,MatDialogRef,MAT_DIALOG_DATA} from '@angular/material'
import { MovieDialoguecomponentComponent } from '../movie-dialoguecomponent/movie-dialoguecomponent.component';
//import { Output } from '@angular/core/src/metadata/directives';
//import { EventEmitter } from 'events';

@Component({
  selector: 'movie-thumbnail',
  templateUrl: './thumbnail.component.html',
  styleUrls: ['./thumbnail.component.css']
})
export class ThumbnailComponent implements OnInit {
 @Input()
  movie:Movie;
  
  @Input()
  usewatchListapi:boolean;

  @Output()
  addMovie=new EventEmitter();
  @Output()
  deleteMovie=new EventEmitter();
  @Output()
  updateMovie=new EventEmitter();

  
  constructor(private dailog:MatDialog) {
    //this.movies = [];
  }


  ngOnInit() {
    
  
  }
   addMoviestowatchList()
   {
     this.addMovie.emit(this.movie);
    
   }
   deleteMovieFromwatchList()
   {
     console.log(`${this.movie.title} here is the movie obj`)
     this.deleteMovie.emit(this.movie);
    
   }
   updateFromwatchlist(actionType)
   {

    console.log("Inside movie upload");
   let dialogRef=this.dailog.open (MovieDialoguecomponentComponent,{

    width:'400px',
    data:{obj:this.movie,actionType:actionType}
   });
   console.log('opening dialog ')

   dialogRef.afterClosed().subscribe(result =>{
     console.log("This dialog was closed");
   }
  );
   }

}
