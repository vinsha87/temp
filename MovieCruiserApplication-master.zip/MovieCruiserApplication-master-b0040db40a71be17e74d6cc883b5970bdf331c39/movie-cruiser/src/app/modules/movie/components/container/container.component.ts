import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'movie-container',
  template: `<movie-container>moviee</movie-container>`,
  styleUrls: ['./container.component.css']
})
export class ContainerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
