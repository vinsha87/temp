import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MovieDialoguecomponentComponent } from './movie-dialoguecomponent.component';

describe('MovieDialoguecomponentComponent', () => {
  let component: MovieDialoguecomponentComponent;
  let fixture: ComponentFixture<MovieDialoguecomponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MovieDialoguecomponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MovieDialoguecomponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
