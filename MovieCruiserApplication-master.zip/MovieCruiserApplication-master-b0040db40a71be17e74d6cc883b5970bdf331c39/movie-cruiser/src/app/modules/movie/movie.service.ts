import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators/map';
import { Movie } from './movie';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class MovieService {
    apiKey: string;
    tmdbEndpoint: string;
    imagePrefix: string;
    endpoint: string;
    movieEndPoint:string;
    watchListEndpoint:string;
    springBootEndpoint:string;
    searchUrl:string;
    searchapikey:string;

    constructor(private http: HttpClient) {
        this.apiKey = "?api_key=a33d541cfee0b67e58c49a1492249931";
        this.searchapikey = "a33d541cfee0b67e58c49a1492249931";
        this.tmdbEndpoint = "https://api.themoviedb.org/3/movie";
        this.endpoint = "https://api.themoviedb.org/3/movie";
        this.imagePrefix="https://image.tmdb.org/t/p/w500";
        this.watchListEndpoint="http://localhost:8080/watchlist";
        this.springBootEndpoint="http://localhost:8080/api/movie";
        this.searchUrl="https://api.themoviedb.org/3/search/movie?";
    }
    getMovies(type:string,page:number=1): Observable<Array<Movie>> {
        //console.log("type ----"+type);
        this.movieEndPoint=`${this.endpoint}/${type}${this.apiKey}&page=${page}`;
       //console.log("movieEndPoint ----"+this.movieEndPoint);
        return this.http.get(this.movieEndPoint).pipe(
            map(this.getResults),
            map(this.updatePosterPath.bind(this)));

    }
    getPopularMovies(): Observable<Array<Movie>> {
        return this.http.get(this.tmdbEndpoint).pipe(
            map(this.getResults),
            map(this.updatePosterPath.bind(this)));

    }
    updatePosterPath(movies): Observable<Array<Movie>> {
        return movies.map(movie => {
            movie.poster_path = `${this.imagePrefix}${movie.poster_path}`;
            //console.log("movie.poster_path ----"+movie.poster_path);
            return movie;
        });
    }
    getResults(response) {
        return response['results'];
    }
    getWatchListMovies(): Observable<Array<Movie>> {
        return this.http.get<Array<Movie>>(this.springBootEndpoint);
    }

    addMoviesToWatchList(movie){
        return this.http.post(this.springBootEndpoint,movie);
    }

    deleteMovieFromwatchList(movie:Movie)
    {
         const url=`${this.springBootEndpoint}/${movie.id}`;
         
         console.log("url:"+url)
        return this.http.delete(url,{responseType:'json'});
    }
    updateMovieFromwatchList(movie:Movie)
    {
         const url=`${this.springBootEndpoint}/${movie.id}`;
         
         console.log("url:"+url)
        return this.http.put(url,movie);
    }

    searchMovies(searchkey:string):Observable<Array<Movie>> 
    {
        if(searchkey.length>0)
        {

        const url =`${this.searchUrl}api_key=${this.searchapikey}&language=en-US&page=1&include_adult=false&query=${searchkey}`;
        return this.http.get(url).pipe(
            map(this.getResults),
            map(this.updatePosterPath.bind(this)));;
        
        }
    }
}