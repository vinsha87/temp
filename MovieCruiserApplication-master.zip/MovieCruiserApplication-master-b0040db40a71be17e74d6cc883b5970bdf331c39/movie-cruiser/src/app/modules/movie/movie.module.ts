import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { HelloWorldComponent } from './components/hello-world/hello-world.component';
import { ThumbnailComponent } from './components/thumbnail/thumbnail.component';
import { MovieService } from './movie.service'
import { HttpClientModule } from '@angular/common/http';
import { ComponentComponent } from './components/component/component.component';
import { RouterModule, Routes } from '@angular/router';
import { MovieRouterModule } from './movie-router.module';
import { ContainerComponent } from './components/container/container.component';
import { MatCardModule, MatSnackBar } from '@angular/material';
import { MatButtonModule } from '@angular/material/button';
import { WatchListComponent } from './components/watch-list/watch-list.component';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import { TmdbContainerComponent } from './components/tmdb-container/tmdb-container.component';
import { MovieDialoguecomponentComponent } from './components/movie-dialoguecomponent/movie-dialoguecomponent.component';
import {MatDialogModule} from '@angular/material/dialog'
import {FormsModule} from '@angular/forms'
import {MatInputModule} from '@angular/material/input';
import { SearchComponent } from './components/search/search.component';
import { MovieUtility } from './movie-utility';
import { TokenInterceptor } from './interceptor.service';
@NgModule({
  imports: [
    CommonModule,
    HttpClientModule,
    MovieRouterModule,MatCardModule,MatButtonModule,MatSnackBarModule, MatInputModule,FormsModule,MatDialogModule
   
  ],
  declarations: [
    HelloWorldComponent,
    ThumbnailComponent,
    ComponentComponent,
    WatchListComponent,
    TmdbContainerComponent,ContainerComponent,
    MovieDialoguecomponentComponent,SearchComponent
  ],
  exports: [
    ComponentComponent,
    ThumbnailComponent
  ],
  providers: [
    MovieService,{ provide: HTTP_INTERCEPTORS, useClass: TokenInterceptor, multi: true },
    MovieUtility
  ],
  entryComponents :[MovieDialoguecomponentComponent]
})
export class MovieModule { }
