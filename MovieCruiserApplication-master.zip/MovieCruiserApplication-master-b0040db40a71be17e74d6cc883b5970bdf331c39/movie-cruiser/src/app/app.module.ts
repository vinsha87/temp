import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {MatButtonModule} from '@angular/material/button';
import { AppComponent } from './app.component';
import { MatToolbarModule, MatToolbar} from '@angular/material/toolbar';
import { MovieModule } from './modules/movie/movie.module';
import { MovieService } from './modules/movie/movie.service';
import { MatCardModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatDialogModule} from '@angular/material/dialog'
import {FormsModule} from '@angular/forms'
import {MatInputModule} from '@angular/material/input';
import { MovieDialoguecomponentComponent } from './modules/movie/components/movie-dialoguecomponent/movie-dialoguecomponent.component';
import { AuthenticationModule } from './modules/authentication/authentication.module';
import { AuthguardService } from './authguard.service';
import {LoginComponent} from './modules/authentication/login/login.component'
const appRoutes: Routes = [{
  path: '',
  redirectTo: '/login',
  pathMatch: 'full'
  },
  {
    path: 'login',
    component: LoginComponent
  }]
@NgModule({
  declarations: [
    AppComponent,
    
   
   
   
  ],
  imports: [
    BrowserModule, 
    MovieModule,MatCardModule,
    BrowserAnimationsModule,
    MatDialogModule,
    FormsModule,
    MatToolbarModule,MatButtonModule,
    RouterModule.forRoot(appRoutes),
    MatInputModule,FormsModule,MatDialogModule,
    AuthenticationModule,
  ],
  providers: [AuthguardService],
  bootstrap: [AppComponent]
})
export class AppModule { }
