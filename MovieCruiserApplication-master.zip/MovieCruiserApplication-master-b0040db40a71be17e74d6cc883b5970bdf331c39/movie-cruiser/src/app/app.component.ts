import { Component } from '@angular/core';
import {AuthenticationService} from "./modules/authentication/auth-service.service";
import { Router } from '@angular/router';
@Component({
  selector: 'app-root',
  template: `
  <mat-toolbar color="primary">
  <span>MovieCruiser App</span>
  <button mat-button [routerLink]="['./movies/popular']">Popular Movies</button>
  <button mat-button [routerLink]="['./movies/top_rated']">TopRated Movies</button>
  <button mat-button [routerLink]="['./movies/watchList']">Watch List</button>
  <button mat-button [routerLink]="['./movies/search']">Search</button>
  <button mat-button  (click)="logout()">Logout</button>
  </mat-toolbar>
  
<router-outlet></router-outlet>`,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(private auth :AuthenticationService,private route:Router){};
  

  title = 'app';
  logout(){
    console.log("logging out the user");
    this.auth.deleteToken();
    this.route.navigate(['/login']);
    console.log("Redirected")
  
  }
}

