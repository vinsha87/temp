#!/bin/bash
echo "GOING TO LOGIN"
sudo docker login 



