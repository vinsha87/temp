export class ReviewResponse {
    user_reviews: UserReviews[];
    status: string;
    message:string;
}

export class UserReviews {
    review: Review;
}

export class Review {
    rating_text: string;
    id: string;
    comments_count: string;
    rating_color: string;
    likes: string;
    rating: string;
    review_text: string;
    user: User;
}

export class User {
    profile_url: string;
    name: string;
    foodie_level: string;
    foodie_color: string;
}
