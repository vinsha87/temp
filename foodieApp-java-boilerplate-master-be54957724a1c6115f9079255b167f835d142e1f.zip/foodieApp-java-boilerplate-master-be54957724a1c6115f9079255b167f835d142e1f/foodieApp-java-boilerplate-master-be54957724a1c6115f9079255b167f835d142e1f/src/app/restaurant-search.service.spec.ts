import { TestBed, inject } from '@angular/core/testing';
import { Http } from '@angular/http';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { RestaurantSearchService } from './restaurant-search.service';
import { HttpClient, HttpHeaders, HttpClientModule } from '@angular/common/http';

describe('RestaurantSearchService', () => {

  let spyHttp: jasmine.SpyObj<HttpClient>
  let service: RestaurantSearchService;

  const favList = {
    'favouriteRestaur': [900716]


  };
  const restaurant: any = {
    'restaurant': {
      'name': 'test',
      'id': 900716

    }

  }
  beforeEach(() => {
    const httpSpy = jasmine.createSpyObj('HttpClient', ['get', 'post', 'delete']);
    TestBed.configureTestingModule({
      imports: [HttpClientModule],
      providers: [RestaurantSearchService, { provide: HttpClient, useValue: httpSpy },]
    }).compileComponents();

    service = TestBed.get(RestaurantSearchService);
    spyHttp = TestBed.get(HttpClient);
  });

  it('should be created', inject([RestaurantSearchService], (service: RestaurantSearchService) => {
    expect(service).toBeTruthy();
  }));

  it('should be able to Add Restaurant.', () => {
    spyHttp.post.and.returnValue(Observable.of(true));
    service.addFavouriteRestaurant(restaurant);
    expect(spyHttp.post.calls.count()).toBe(1);
    console.log('should be able to Add Restaurant.');
  });

  it('should be able to Remove Restaurant from Favourite page', () => {
    spyHttp.post.and.returnValue(Observable.of(true));
    service.removeFavouriteCard(restaurant);
    expect(spyHttp.delete.calls.count()).toBe(1);
    console.log('should be able to Remove Restaurant from Favourite page.');
  });

  it('should be able to Remove Restaurant from Search Page', () => {
    spyHttp.post.and.returnValue(Observable.of(true));
    service.removeFavourite(restaurant);
    expect(spyHttp.delete.calls.count()).toBe(1);
    console.log('should be able to Remove Restaurant from Search Page');
  });


});




