import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { ListRestaurantComponent } from './list-restaurant/list-restaurant.component';
import { RestaurantSearchService } from './restaurant-search.service';
import { AppRoutingModuleModule } from './app-routing-module/app-routing-module.module';
import { FavListComponent } from './fav-list/fav-list.component';
import { ViewRestaurantComponent } from './view-restaurant/view-restaurant.component';
export const myComponents = [
  AppComponent
];

@NgModule({
  declarations: [
    ...myComponents,
    ListRestaurantComponent,
    FavListComponent,
    ViewRestaurantComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModuleModule
  ],
  providers: [RestaurantSearchService],
  bootstrap: [AppComponent]
})
export class AppModule { }
