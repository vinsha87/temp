

export class FavouriteRestaurantDetail {
    favouritRestaurantList: FavouriteRestaurant[];
    status: string;
    message:string;
}

export class FavouriteRestaurant {
    favourite: boolean;
    cuisines: string;
    photos_url: string;
    has_online_delivery: string;
    location: Location;
    featured_image: string;
    offers: string[];
    menu_url: string;
    is_delivering_now: string;
    url: string;
    switch_to_order_menu: string;
    user_rating: UserRating;
    apikey: string;
    currency: string;
    id: string;
    price_range: string;
    name: string;
    deeplink: string;
    events_url: string;
    average_cost_for_two: string;
    thumb: string;
    has_table_booking: string;

}

export class Location {
    city_id: string;
    location_verbose: string;
    country_id: string;
    address: string;
    zipcode: string;
    locality: string;
    longitude: string;
    latitude: string;
    city: string;
}

export class UserRating {
    rating_text: string;
    rating_color: string;
    votes: string;
    aggregate_rating: string;
}

