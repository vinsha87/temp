import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ListRestaurantComponent } from '../list-restaurant/list-restaurant.component';
import { ViewRestaurantComponent } from '../view-restaurant/view-restaurant.component';
import { FavListComponent } from '../fav-list/fav-list.component';

const routes: Routes = [
  { path: 'viewRestaurant/:id', component: ViewRestaurantComponent },
  { path: 'favourites', component: FavListComponent },
  { path: 'search', component: ListRestaurantComponent },
  { path: '', redirectTo: '/search', pathMatch: 'full' }
];



@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]

})
export class AppRoutingModuleModule { }
