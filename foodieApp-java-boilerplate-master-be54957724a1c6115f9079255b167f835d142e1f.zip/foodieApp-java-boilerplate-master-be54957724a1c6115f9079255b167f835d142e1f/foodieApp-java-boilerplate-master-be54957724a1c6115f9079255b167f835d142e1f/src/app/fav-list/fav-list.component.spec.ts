import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { FavouriteRestaurantDetail, FavouriteRestaurant, Location, UserRating } from '../favouriteRestaurant';
import { RestaurantSearchService } from '../restaurant-search.service';
import { SearchRestaurantsResponse } from '../restaurantSearch';
import { Restaurants, Restaurant } from '../restaurantSearch';
import { FavouriteDetails, FavouriteResponse } from '../restaurantSearch';
import { Http } from '@angular/http';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FavListComponent } from './fav-list.component';

describe('FavListComponent', () => {
  let component: FavListComponent;
  let fixture: ComponentFixture<FavListComponent>;
  let testaurantSearchService: RestaurantSearchService;
  const router = {
    navigate: jasmine.createSpy('viewRestaurant')
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FavListComponent], providers: [RestaurantSearchService,
        { provide: HttpClient, useValue: {} },
        { provide: Router, useValue: router }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FavListComponent);
    component = fixture.componentInstance;

    const favouriteRestaurantDetail = new FavouriteRestaurantDetail();

    const favouriteRestaurant = new FavouriteRestaurant();
    favouriteRestaurant.id = '123';
    favouriteRestaurant.featured_image = 'https://b.zmtcdn.com/data/res_imagery/901830_RESTAURANT_92f403912757b7f446ca6b3766494b8a.jpg';
    favouriteRestaurant.name = 'Art Cafe';
    favouriteRestaurant.currency = 'Rs';
    favouriteRestaurant.average_cost_for_two = '700';
    favouriteRestaurant.favourite = false;
    const location = new Location();
    location.address = 'test';
    favouriteRestaurant.location = location;

    const user_rating = new UserRating();
    user_rating.aggregate_rating = 'good';
    user_rating.votes = '100';
    user_rating.aggregate_rating = '100';
    user_rating.rating_text = 'good';
    favouriteRestaurant.user_rating = user_rating;

    const favouriteRestDetails = [favouriteRestaurant];
    favouriteRestaurantDetail.favouritRestaurantList = favouriteRestDetails;


    testaurantSearchService = TestBed.get(RestaurantSearchService);
    spyOn(testaurantSearchService, 'showFavourites').and.returnValue(Observable.of(favouriteRestaurantDetail));
    spyOn(testaurantSearchService, 'removeFavouriteCard').and.returnValue(Observable.of(''));


    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });


  it('should be able to call API to fetch Favourite Restaurant', () => {
    component.ngOnInit();
    expect(testaurantSearchService.showFavourites).toHaveBeenCalled();

    fixture.detectChanges();
    console.log('test for search restaurants');
  }
  );

  it('should be able to call API to remove Favourite Restaurant', () => {
    component.removeFavourite(this.favouriteRestaurant);
    expect(testaurantSearchService.removeFavouriteCard).toHaveBeenCalled();

    fixture.detectChanges();
    console.log('test for search restaurants');
  }
  );

});


