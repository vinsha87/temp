import { Component, OnInit } from '@angular/core';
import { RestaurantSearchService } from '../restaurant-search.service';
import { SearchRestaurantsResponse } from '../restaurantSearch';
import { FavouriteRestaurantDetail, FavouriteRestaurant } from '../favouriteRestaurant';
@Component({
  selector: 'app-fav-list',
  templateUrl: './fav-list.component.html',
  styleUrls: ['./fav-list.component.css']
})
export class FavListComponent implements OnInit {
  private favresultset: FavouriteRestaurantDetail;
  constructor(private searchservice: RestaurantSearchService) { }

  ngOnInit() {
    this.fetchFavourites();

  }
  fetchFavourites() {
    this.searchservice.showFavourites().subscribe(data => {
      this.favresultset = data;

    });
  }

  removeFavourite(fav: FavouriteRestaurant) {
    console.log('addFavourite');
    this.searchservice.removeFavouriteCard(fav).subscribe(data => {
      if (data) {
        fav.favourite = false;
        this.fetchFavourites();
      }

    });

  }


}
