import { Component, OnInit } from '@angular/core';
import { ReviewResponse } from '../reviewResponse';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { Params } from '@angular/router/src/shared';
import { RestaurantSearchService } from '../restaurant-search.service';
import { Restaurant, CommentsResponse } from '../restaurantSearch';
@Component({
  selector: 'app-view-restaurant',
  templateUrl: './view-restaurant.component.html',
  styleUrls: ['./view-restaurant.component.css']
})
export class ViewRestaurantComponent implements OnInit {
  private resultset: ReviewResponse;
  private route$: Subscription;
  private id: String;
  _restaurant: Restaurant;
  private commentResponse: CommentsResponse;

  textComments: string;
  constructor(private searchservice: RestaurantSearchService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.route$ = this.route.params.subscribe(
      (params: Params) => {
        this.id = params['id'];
        this.searchservice.viewSelectedRestaurantReviews(this.id).subscribe(searchData => {

          this.resultset = searchData;

          this._restaurant = this.searchservice.retrieveRestaurant();
          this.searchservice.viewRestaurantComments(this.id).subscribe(dbData => {
            this.commentResponse = dbData;

          });
        });
      }
    );
  }

  saveComments(r: Restaurant, textComments) {
    console.log(':::Inside saveComments');
    console.log(':::id  :', r.id);
    console.log('Comments :', textComments);
    this.searchservice.saveComments(r, textComments).subscribe(data => {


      this.searchservice.viewRestaurantComments(this.id).subscribe(dbData => {
        this.commentResponse = dbData;
        this.textComments = '';
      });
    });


  }

}
