import { Injectable } from '@angular/core';
import { SearchRestaurantsResponse, FavouriteDetails, Restaurant, Comments, CommentsResponse } from './restaurantSearch';

import { FavouriteRestaurantDetail, FavouriteRestaurant } from './favouriteRestaurant';
import { ReviewResponse } from './reviewResponse';
import { Restaurants } from './restaurantSearch';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
@Injectable()
export class RestaurantSearchService {
    private restaurantData: Restaurant;

    private _comments: Comments;
    constructor(private http: HttpClient) {
        this._comments = {
            id: null, resComments: null
        };
    }

    getFavResponse = 'http://localhost:8080/getAllFavourites';
    getDefaultRestaurant = 'http://localhost:8080/getDetail?query=kochi';
    getrestaurants = 'http://localhost:8080/getDetail?query=kochi&cusine=';
    searchRestaurant = 'http://localhost:8080/getDetail?query=';
    searchDetails = '';
    showFavouriteList = 'http://localhost:8080/favouriteList';

    search(): Observable<SearchRestaurantsResponse> {
        console.log('inside search', this.getrestaurants);

        return this.http.get<SearchRestaurantsResponse>(this.getrestaurants);

    }
    showFavourites(): Observable<FavouriteRestaurantDetail> {
        console.log('inside search', this.showFavouriteList);

        return this.http.get<FavouriteRestaurantDetail>(this.showFavouriteList);

    }


    fetchFavourite(): Observable<FavouriteDetails> {
        console.log('inside search', this.getFavResponse);

        return this.http.get<FavouriteDetails>(this.getFavResponse);

    }

    searchRestaurantDetails(location, cusine): Observable<SearchRestaurantsResponse> {

        this.searchDetails = '';
        console.log('value os location  :', location);
        console.log('value of cuisine   :', cusine);
        if (location == null || location === '') {
            console.log('location is null', location);
            this.searchDetails = this.getDefaultRestaurant;
        } else {
            console.log('inside search location', location);
            this.getrestaurants = 'http://localhost:8080/getDetail?query=' + location;
            this.searchDetails = this.getrestaurants;
        }
        if (cusine == null || cusine === '') {
            this.searchDetails = this.searchDetails + '&cusine=';
        } else {
            this.searchDetails = this.searchDetails + '&cusine=' + cusine;

        }


        return this.http.get<SearchRestaurantsResponse>(this.searchDetails);

    }
    saveRestaurant(restaurant: Restaurants) {
        console.log('Restaurant Name:::::', restaurant.restaurant.name);
        this.restaurantData = restaurant.restaurant;
    }

    retrieveRestaurant() {
        console.log('Restaurant Name:::::>', this.restaurantData.name);
        return this.restaurantData;
    }

    viewSelectedRestaurantReviews(id): Observable<ReviewResponse> {

        return this.http.get<ReviewResponse>('http://localhost:8080/review?res_id=' + id);
    }

    viewRestaurantComments(id): Observable<CommentsResponse> {

        return this.http.get<CommentsResponse>('http://localhost:8080/comments?res_id=' + id);

    }

    addFavouriteRestaurant(restaurant: Restaurants): Observable<string> {
        console.log('restaurant   :', restaurant);
        return this.http.post<string>('http://localhost:8080/addFavRestaurant', restaurant.restaurant.id);
    }

    saveComments(r: Restaurant, comments): Observable<Comments> {
        console.log('---', r.id);
        this._comments.id = r.id;
        this._comments.resComments = comments;
        console.log('this._comments', this._comments);
        return this.http.post<Comments>('http://localhost:8080/addComments', this._comments);
    }


    removeFavourite(restaurant: Restaurants) {
        console.log('delete   :', restaurant.restaurant.id);
        return this.http.delete<string>('http://localhost:8080/removeFavRestaurant/' + restaurant.restaurant.id);
    }

    removeFavouriteCard(restaurant: FavouriteRestaurant) {
        console.log('delete   :', restaurant.id);
        return this.http.delete<string>('http://localhost:8080/removeFavRestaurant/' + restaurant.id);
    }

}
