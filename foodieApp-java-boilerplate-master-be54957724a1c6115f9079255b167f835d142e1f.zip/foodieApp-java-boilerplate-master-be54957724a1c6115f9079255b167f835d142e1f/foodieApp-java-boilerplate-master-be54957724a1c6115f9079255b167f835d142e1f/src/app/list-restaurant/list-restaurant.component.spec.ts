

import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { ListRestaurantComponent } from './list-restaurant.component';
import { RestaurantSearchService } from '../restaurant-search.service';
import { SearchRestaurantsResponse } from '../restaurantSearch';
import { Restaurants, Restaurant, Location, UserRating } from '../restaurantSearch';
import { FavouriteDetails, FavouriteResponse, } from '../restaurantSearch';
import { Http } from '@angular/http';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import { HttpClient, HttpHeaders } from '@angular/common/http';
describe('ListRestaurantComponent', () => {
  let component: ListRestaurantComponent;
  let fixture: ComponentFixture<ListRestaurantComponent>;
  let testaurantSearchService: RestaurantSearchService;
  let restaurantdata: Restaurant;
  const router = {
    navigate: jasmine.createSpy('viewRestaurant')
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule],
      declarations: [ListRestaurantComponent], providers: [RestaurantSearchService,
        { provide: HttpClient, useValue: {} },
        { provide: Router, useValue: router }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListRestaurantComponent);
    component = fixture.componentInstance;
    const searchRestaurantsResponse = new SearchRestaurantsResponse();

    const restaurant = new Restaurant();
    restaurant.favourite = false;
    restaurant.name = 'test';
    restaurant.id = '123';
    restaurant.featured_image = 'https://b.zmtcdn.com/data/res_imagery/901830_RESTAURANT_92f403912757b7f446ca6b3766494b8a.jpg';
    const location = new Location();
    location.address = 'test';
    restaurant.location = location;

    restaurant.currency = 'RS';
    restaurant.average_cost_for_two = '700';
    const user_rating = new UserRating();
    user_rating.aggregate_rating = 'good';
    user_rating.votes = '100';
    user_rating.aggregate_rating = '100';
    user_rating.rating_text = 'good';
    restaurant.user_rating = user_rating;

    const restaurants = new Restaurants();
    restaurants.restaurant = restaurant;
    searchRestaurantsResponse.restaurants = [restaurants];


    const favouriteResponse = new FavouriteResponse();
    favouriteResponse.restaurantId = '123';
    const favouriteRespDetails = [favouriteResponse];
    const favouriteDetails = new FavouriteDetails();
    favouriteDetails.favouriteResponse = favouriteRespDetails;
    
    let cusine = 'test';
    let locationData = 'kochi';


    testaurantSearchService = TestBed.get(RestaurantSearchService);
    spyOn(testaurantSearchService, 'search').and.returnValue(Observable.of(searchRestaurantsResponse));
    spyOn(testaurantSearchService, 'fetchFavourite').and.returnValue(Observable.of(favouriteDetails));
    spyOn(testaurantSearchService, 'addFavouriteRestaurant').and.returnValue(Observable.of(this.result));
    spyOn(testaurantSearchService, 'removeFavourite').and.returnValue(Observable.of(this.result));
    spyOn(testaurantSearchService, 'searchRestaurantDetails').and.returnValue(Observable.of(searchRestaurantsResponse));


    fixture.detectChanges();
  });

  it('should be created', () => {
    console.log('done');
    expect(component).toBeTruthy();
    console.log('done');
  });

  it('should be able to call API to get Restaurants', () => {
    component.ngOnInit();
    expect(testaurantSearchService.search).toHaveBeenCalled();

    fixture.detectChanges();
    console.log('test for search restaurants');
  }
  );

  it('should be able to call API to fetch Favourite', () => {
    component.fetchFromFav();
    expect(testaurantSearchService.fetchFavourite).toHaveBeenCalled();
    fixture.detectChanges();
    console.log('test for fetchFavourite');
  }
  );
  it('should be able to call  Add Restaurant', () => {
    component.addFavourite(this.restaurant);
    expect(testaurantSearchService.addFavouriteRestaurant).toHaveBeenCalled();
    fixture.detectChanges();
    console.log('test for addFavourite');
  }
  );

  it('should be able to call  remove Restaurant', () => {
    component.removeFavourite(this.restaurant);
    expect(testaurantSearchService.removeFavourite).toHaveBeenCalled();
    fixture.detectChanges();
    console.log('test for remove Restaurant from Favourite');
  }
  );

  it('should be able to fetch  Restaurant', () => {
    component.searchForRestaurants(this.locationData, this.cusine);
    expect(testaurantSearchService.searchRestaurantDetails).toHaveBeenCalled();
    fixture.detectChanges();
    console.log('test for fetch  Restaurant');
  }
  );





});

