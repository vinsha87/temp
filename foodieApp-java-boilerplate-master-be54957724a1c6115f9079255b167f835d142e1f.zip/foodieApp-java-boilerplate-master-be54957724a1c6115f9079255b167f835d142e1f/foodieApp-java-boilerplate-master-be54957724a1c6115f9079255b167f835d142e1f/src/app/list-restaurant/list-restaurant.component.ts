import { Component, OnInit } from '@angular/core';
import { RestaurantSearchService } from '../restaurant-search.service';
import { SearchRestaurantsResponse } from '../restaurantSearch';
import { Restaurants } from '../restaurantSearch';
import { FavouriteDetails } from '../restaurantSearch';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-restaurant',
  templateUrl: './list-restaurant.component.html',
  styleUrls: ['./list-restaurant.component.css']
})
export class ListRestaurantComponent implements OnInit {
  private resultset: SearchRestaurantsResponse;
  private resultsetFiltered: SearchRestaurantsResponse;
  private favResultSet: FavouriteDetails;
  location: string;
  cusine: string;
  statusMsg:string;
  constructor(private searchservice: RestaurantSearchService, private p_route: Router) {

  }
  onCardClick(restaurant: Restaurants) {

    this.searchservice.saveRestaurant(restaurant);
    this.p_route.navigate(['viewRestaurant/' + restaurant.restaurant.id]);

  }

  ngOnInit() {
    console.log('inside init method');

    this.searchservice.search().subscribe(data => {
      this.resultset = data;
     
      this.statusMsg=this.resultset.status;
      
      this.fetchFromFav();

    });



  }

  fetchFromFav() {
    this.searchservice.fetchFavourite().subscribe(dbData => {

      this.favResultSet = dbData;
      console.log('Restaurant ', this.resultset);
      console.log('favResultSet', this.favResultSet);
      for (const res of this.resultset.restaurants) {

        for (const f of this.favResultSet.favouriteResponse) {
          if (f.restaurantId === res.restaurant.id) {

            res.restaurant.favourite = true;
          }
        }

      }
    });
  }

  searchForRestaurants(location, cusine) {
    console.log('Searched Location  :', location);
    console.log('Searched cusine  :', cusine);
    this.searchservice.searchRestaurantDetails(this.location, this.cusine).subscribe(data => {
      this.resultset = data;
      this.fetchFromFav();

    });
    this.location = '';
    this.cusine = '';
  }

  addFavourite(restaurant: Restaurants) {
    console.log(' inside addFavourite');
    this.searchservice.addFavouriteRestaurant(restaurant).subscribe(data => {
      if (data) {
        restaurant.restaurant.favourite = true;
      }
    });

  }

  removeFavourite(restaurant: Restaurants) {
    console.log('inside removeFavourite');
    this.searchservice.removeFavourite(restaurant).subscribe(data => {
      if (data) {
        restaurant.restaurant.favourite = false;
      }
    });

  }

}
