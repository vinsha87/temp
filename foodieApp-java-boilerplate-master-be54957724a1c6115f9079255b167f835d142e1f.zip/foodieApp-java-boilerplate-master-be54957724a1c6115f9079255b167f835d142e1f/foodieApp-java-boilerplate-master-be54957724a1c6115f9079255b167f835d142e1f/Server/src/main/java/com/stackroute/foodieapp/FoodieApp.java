package com.stackroute.foodieapp;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
@SpringBootApplication
@ComponentScan("com.stackroute")
@EntityScan("com.stackroute.model")
public abstract class FoodieApp {

	public static void main(String[] args) {
		SpringApplication.run(FoodieApp.class, args);
	}
	
	
}