package com.stackroute.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LocationFetch {
	@JsonProperty("location_suggestions")
	private List<LocationSuggestions> locationSuggestions;

	public List<LocationSuggestions> getLocationSuggestions() {
		return locationSuggestions;
	}

	public void setLocationSuggestions(List<LocationSuggestions> locationSuggestions) {
		this.locationSuggestions = locationSuggestions;
	}

	

}
