package com.stackroute.model;

public class UserReviews {
	private Review review;

	public Review getReview() {
		return review;
	}

	public void setReview(Review review) {
		this.review = review;
	}

	
	
	

}
