package com.stackroute.model;

import java.util.List;

public class SearchRestaurantsResponse {
	
	private List<Restaurants> restaurants;
	private String status;
	private String message;
	
	public List<Restaurants> getRestaurants() {
		return restaurants;
	}
	public void setRestaurants(List<Restaurants> restaurants) {
		this.restaurants = restaurants;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	
	
		
}
