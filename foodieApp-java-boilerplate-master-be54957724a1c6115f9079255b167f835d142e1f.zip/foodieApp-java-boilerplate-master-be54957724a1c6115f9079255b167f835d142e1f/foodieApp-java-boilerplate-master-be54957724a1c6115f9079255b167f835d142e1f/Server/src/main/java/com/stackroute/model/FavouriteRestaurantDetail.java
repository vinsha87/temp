package com.stackroute.model;

import java.util.List;

public class FavouriteRestaurantDetail {
	List<FavouriteRestaurant> favouritRestaurantList ;
	private String status;
	private String message;

	public List<FavouriteRestaurant> getFavouritRestaurantList() {
		return favouritRestaurantList;
	}

	public void setFavouritRestaurantList(List<FavouriteRestaurant> favouritRestaurantList) {
		this.favouritRestaurantList = favouritRestaurantList;
	}

	public String getStatus() {
		return status;
	}

	public String getMessage() {
		return message;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	
	
}
