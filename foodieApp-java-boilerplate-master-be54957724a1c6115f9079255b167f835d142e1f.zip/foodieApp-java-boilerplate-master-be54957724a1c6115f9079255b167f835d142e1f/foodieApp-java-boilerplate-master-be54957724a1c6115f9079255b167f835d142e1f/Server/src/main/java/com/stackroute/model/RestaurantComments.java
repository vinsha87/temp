package com.stackroute.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="restaurant_comments",schema="foodieapp")
public class RestaurantComments {
	

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	@Column(name="restaurant_id")
	private Integer restaurantId;
	
	@Column(name="res_comments")
	private String resComments;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getRestaurantId() {
		return restaurantId;
	}

	public void setRestaurantId(Integer restaurantId) {
		this.restaurantId = restaurantId;
	}

	public String getResComments() {
		return resComments;
	}

	public void setResComments(String resComments) {
		this.resComments = resComments;
	}

	public RestaurantComments(Integer restaurantId, String resComments) {
		
		this.restaurantId = restaurantId;
		this.resComments = resComments;
	}

	public RestaurantComments(Integer restaurantId) {
		
		this.restaurantId = restaurantId;
	}
	
	/**
	 * Create default instance
	 */
	public RestaurantComments(){
	}

}
