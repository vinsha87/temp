package com.stackroute.model;

public class RestResponse {
	
	private String responseStatus;

	public String getResponseStatus() {
		return responseStatus;
	}

	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}

	
	

}
