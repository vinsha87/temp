package com.stackroute.foodieapp;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;

import com.stackroute.foodieapp.service.FoodieAppService;
import com.stackroute.model.Comments;
import com.stackroute.model.CommentsResponse;
import com.stackroute.model.FavouriteDetails;
import com.stackroute.model.FavouriteRestaurant;
import com.stackroute.model.FavouriteRestaurantDetail;
import com.stackroute.model.LocationSuggestions;
import com.stackroute.model.RestResponse;
import com.stackroute.model.ReviewResponse;
import com.stackroute.model.SearchRestaurantsResponse;

@RestController
@CrossOrigin
public class FoodieAppController {

	

	private static final String NO_DATA_FOUND = "No Data found for the Location";
	private static final String INFO = "INFO";
	private static final String PLEASE_TRY_AGAIN = "Something went Wrong. Please try again!";
	private static final String ERROR = "ERROR";
	@Autowired
	FoodieAppService foodieAppService;



	@RequestMapping(value = "/comments", method = RequestMethod.GET)
	public CommentsResponse getComments(@RequestParam("res_id") final String res_id) {

		return foodieAppService.getComments(res_id);
	}

	@RequestMapping(value = "/review", method = RequestMethod.GET)
	public ReviewResponse getReviews(@RequestParam("res_id") final String res_id) {

		return foodieAppService.getReviews(res_id);
	}

	@RequestMapping(value = "/addFavRestaurant", method = RequestMethod.POST)
	public RestResponse addFavRestaurant(@RequestBody final String restaurantId) {

		return foodieAppService.addFavRestaurant(restaurantId);

	}

	@RequestMapping(value = "/addComments", method = RequestMethod.POST)
	public RestResponse addRestaurantComments(@RequestBody final Comments comments) {

		return foodieAppService.addRestaurantComments(comments);

	}

	@RequestMapping(value = "/getAllFavourites", method = RequestMethod.GET)
	public FavouriteDetails getAllFavourites() {

		return foodieAppService.getAllFavourites();
	}

	@RequestMapping(value = "/removeFavRestaurant/{restaurantId}", method = RequestMethod.DELETE)
	public RestResponse removeFavRestaurant(@PathVariable final String restaurantId) {

		return foodieAppService.removeFavRestaurant(restaurantId);

	}

	@RequestMapping(value = "/getDetail", method = RequestMethod.GET)
	public SearchRestaurantsResponse getDetail(@RequestParam("query") final String query,
			@RequestParam("cusine") final String cusine) {
		LocationSuggestions locSuggest;
		String cuisineId=null;
		List<LocationSuggestions> listLocation=null;
		SearchRestaurantsResponse resp=new SearchRestaurantsResponse();
		try{
		 listLocation = foodieAppService.fetchLocationDetails(query);
		}catch(RestClientException ex){
			resp.setStatus(ERROR);
			resp.setMessage(PLEASE_TRY_AGAIN);
		}
		if (null != listLocation && listLocation.size() > 0) {
			locSuggest = listLocation.get(0);
			String entityId = locSuggest.getEntityId();
			String entityType = locSuggest.getEntityType();
			String cityName = locSuggest.getCityName();
			
			 resp = foodieAppService.getDetail(entityId, entityType, cityName, cusine);

			return resp;
		}
		else{
			resp.setStatus(INFO);
			resp.setMessage(NO_DATA_FOUND);
		}
		return resp;
	}

	@RequestMapping("/favouriteList")
	public FavouriteRestaurantDetail fetchFavList() {

		return foodieAppService.fetchFavList();

	}

	
}
