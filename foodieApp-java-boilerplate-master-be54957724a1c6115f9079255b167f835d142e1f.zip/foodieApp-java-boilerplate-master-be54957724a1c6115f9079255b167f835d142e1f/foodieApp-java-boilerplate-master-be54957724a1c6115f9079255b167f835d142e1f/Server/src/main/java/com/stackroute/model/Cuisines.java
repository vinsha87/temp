package com.stackroute.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Cuisines {
	@JsonProperty("cuisine")
	private Cuisine cuisine;

	public Cuisine getCuisine() {
		return cuisine;
	}

	public void setCuisine(Cuisine cuisine) {
		this.cuisine = cuisine;
	}

	
	
	

}
