package com.stackroute.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LocationSuggestions {
	
	 
		@JsonProperty("city_name")
	    private String cityName;
		
		@JsonProperty("entity_id")
	    private String entityId;
		
		@JsonProperty("entity_type")
	    private String entityType;

		public String getCityName() {
			return cityName;
		}

		public void setCityName(String cityName) {
			this.cityName = cityName;
		}

		public String getEntityId() {
			return entityId;
		}

		public void setEntityId(String entityId) {
			this.entityId = entityId;
		}

		public String getEntityType() {
			return entityType;
		}

		public void setEntityType(String entityType) {
			this.entityType = entityType;
		}

		

		
		

}
