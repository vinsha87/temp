package com.stackroute.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class UserRating {
	@JsonProperty("rating_text")
	private String ratingText;
	
	
	
	@JsonProperty("votes")
	private String votes;
	
	@JsonProperty("aggregate_rating")
	private String aggregateRating;

	

	public String getVotes() {
		return votes;
	}

	public void setVotes(String votes) {
		this.votes = votes;
	}

	public String getRatingText() {
		return ratingText;
	}

	public void setRatingText(String ratingText) {
		this.ratingText = ratingText;
	}

	public String getAggregateRating() {
		return aggregateRating;
	}

	public void setAggregateRating(String aggregateRating) {
		this.aggregateRating = aggregateRating;
	}

	

	

	
	

	
	
}
