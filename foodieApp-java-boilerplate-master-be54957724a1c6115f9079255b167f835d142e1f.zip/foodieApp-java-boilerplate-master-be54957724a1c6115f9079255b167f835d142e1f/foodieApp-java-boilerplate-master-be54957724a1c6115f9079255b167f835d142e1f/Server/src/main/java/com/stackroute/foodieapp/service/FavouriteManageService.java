package com.stackroute.foodieapp.service;

import java.util.AbstractList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.foodieapp.repository.FavouriteRestRepository;
import com.stackroute.foodieapp.repository.SearchRestaurantRepository;
import com.stackroute.model.FavouriteRestEntity;
import com.stackroute.model.RestaurantComments;

@Service
public class FavouriteManageService  extends AbstractList<String>{
	
	@Autowired
	FavouriteRestRepository favRestRepo;
	@Autowired
	SearchRestaurantRepository searchRestRepo;
	
	@Transactional
	public void addRestaurantComments(final Integer restaurantId, final String comments){
		if(null!=restaurantId){
			searchRestRepo.save(new RestaurantComments(restaurantId,comments));
			
		}
	}
	
	
	@Transactional
	public void addFavouriteRestaurant(final Integer restaurantId){
		if(null!=restaurantId){
			favRestRepo.save(new FavouriteRestEntity(restaurantId));
		}
	}
	
	

	@Transactional
	public void removeFavouriteRestaurant(final Integer restaurantId) {
		if (null != restaurantId) {

			FavouriteRestEntity favEntity = favRestRepo.findByRestaurantId(restaurantId);
			favRestRepo.delete(favEntity);

		}
	}
	@Transactional
	public List<FavouriteRestEntity> fetchAll(){
		return favRestRepo.findAll();
	}
	
	@Transactional
	public List<RestaurantComments> fetchAllComments(){
		return searchRestRepo.findAll();
	}


	@Override
	public String get(int index) {
		return null;
	}


	@Override
	public int size() {
		return 0;
	}


	

}

