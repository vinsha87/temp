package com.stackroute.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FavouriteRestaurant {
	private String status;
	private String message;
	private boolean favourite;
	private String cuisines;

	private Location location;

	@JsonProperty("featured_image")
	private String featuredImage;
	private String url;

	@JsonProperty("user_rating")
	private UserRating userRating;

	private String apikey;

	private String currency;

	private String id;

	private String name;

	@JsonProperty("average_cost_for_two")
	private String averageCostForTwo;

	public boolean isFavourite() {
		return favourite;
	}

	public void setFavourite(boolean favourite) {
		this.favourite = favourite;
	}

	public String getCuisines() {
		return cuisines;
	}

	public void setCuisines(String cuisines) {
		this.cuisines = cuisines;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public String getFeaturedImage() {
		return featuredImage;
	}

	public void setFeaturedImage(String featuredImage) {
		this.featuredImage = featuredImage;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public UserRating getUserRating() {
		return userRating;
	}

	public void setUserRating(UserRating userRating) {
		this.userRating = userRating;
	}

	public String getApikey() {
		return apikey;
	}

	public void setApikey(String apikey) {
		this.apikey = apikey;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAverageCostForTwo() {
		return averageCostForTwo;
	}

	public void setAverageCostForTwo(String averageCostForTwo) {
		this.averageCostForTwo = averageCostForTwo;
	}

	public String getStatus() {
		return status;
	}

	public String getMessage() {
		return message;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	

}
