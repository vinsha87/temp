package com.stackroute.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Cuisine {
	@JsonProperty("cuisine_id")
    private String cuisineId;
	
	@JsonProperty("cuisine_name")
    private String cuisineName;

	public String getCuisineId() {
		return cuisineId;
	}

	public void setCuisineId(String cuisineId) {
		this.cuisineId = cuisineId;
	}

	public String getCuisineName() {
		return cuisineName;
	}

	public void setCuisineName(String cuisineName) {
		this.cuisineName = cuisineName;
	}
	
	

}
