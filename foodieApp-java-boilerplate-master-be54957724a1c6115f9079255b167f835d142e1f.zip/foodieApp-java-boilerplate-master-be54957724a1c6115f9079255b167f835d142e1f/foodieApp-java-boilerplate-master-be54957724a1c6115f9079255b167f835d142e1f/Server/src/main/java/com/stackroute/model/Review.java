package com.stackroute.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Review {
	
	private String id;
	
	private String likes;
	private String rating;
	@JsonProperty("review_text")
	private String reviewText;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public String getLikes() {
		return likes;
	}
	public void setLikes(String likes) {
		this.likes = likes;
	}
	
	
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getReviewText() {
		return reviewText;
	}
	public void setReviewText(String reviewText) {
		this.reviewText = reviewText;
	}
	
	
	

}
