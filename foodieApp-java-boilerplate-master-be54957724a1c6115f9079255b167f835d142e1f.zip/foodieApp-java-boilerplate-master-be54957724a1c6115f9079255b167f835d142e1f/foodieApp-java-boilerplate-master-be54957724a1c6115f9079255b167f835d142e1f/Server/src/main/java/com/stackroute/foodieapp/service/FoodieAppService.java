package com.stackroute.foodieapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.stackroute.model.Comments;
import com.stackroute.model.CommentsResponse;
import com.stackroute.model.Cuisines;
import com.stackroute.model.CuisinesList;
import com.stackroute.model.FavouriteDetails;
import com.stackroute.model.FavouriteResponse;
import com.stackroute.model.FavouriteRestEntity;
import com.stackroute.model.FavouriteRestaurant;
import com.stackroute.model.FavouriteRestaurantDetail;
import com.stackroute.model.LocationFetch;
import com.stackroute.model.LocationSuggestions;
import com.stackroute.model.RestResponse;
import com.stackroute.model.RestaurantComments;
import com.stackroute.model.ReviewResponse;
import com.stackroute.model.SearchRestaurantsResponse;

@Service
public class FoodieAppService {

	private static final String SUCCESS2 = "SUCCESS";
	private static final String PLEASE_TRY_AGAIN = "Something went Wrong. Please try again!";
	private static final String ERROR = "ERROR";
	private static final String USER_KEY_VALUE = "55157fe3ac264c545ca10e1d23bbd8c8";
	private static final String USER_KEY = "user-key";
	private static final String RATING = "rating";
	private static final String SORT = "sort";
	private static final String Q = "q";
	private static final String ENTITY_TYPE = "entity_type";
	private static final String ENTITY_ID = "entity_id";
	private static final String SUCCESS = SUCCESS2;
	@Autowired
	FavouriteManageService favService;
	
	@Autowired
	private RestTemplateBuilder restbuilder;
	
	

	public CommentsResponse getComments(final String res_id) {
		return fetchComments(res_id);
		
	}

	public CommentsResponse fetchComments(final String res_id) {
		List<RestaurantComments> resCommentsList = favService.fetchAllComments();
		List<Comments> commentList = new ArrayList<>();
		CommentsResponse commentsResponse = new CommentsResponse();
		for (RestaurantComments com : resCommentsList) {
			Comments response = new Comments();
			Integer id = Integer.parseInt(res_id);
			if (id.equals(com.getRestaurantId())) {
				response.setResComments(com.getResComments());
				commentList.add(response);
			}

		}
		commentsResponse.setComments(commentList);
		return commentsResponse;
	}

	public ReviewResponse getReviews(final String res_id) {
		String url = "https://developers.zomato.com/api/v2.1/reviews";
		ReviewResponse reviewResponse= new ReviewResponse();
		reviewResponse.setStatus(SUCCESS2);
		try{
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url).queryParam("res_id", res_id);

		HttpEntity<String> httpEntity = new HttpEntity<>(createHeader());
		//RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<ReviewResponse> response = restbuilder.build().exchange(builder.toUriString(), HttpMethod.GET,
				httpEntity, ReviewResponse.class, new Object());
		
		reviewResponse=response.getBody();
		}catch(RestClientException ex){
			handleException(reviewResponse);
		}
		return reviewResponse;

	}

	private void handleException(ReviewResponse reviewResponse) {
		reviewResponse.setStatus(ERROR);
		reviewResponse.setMessage(PLEASE_TRY_AGAIN);
	}

	public RestResponse addFavRestaurant(final String restaurantId) {
		RestResponse response = new RestResponse();
		favService.addFavouriteRestaurant(Integer.valueOf(restaurantId));
		response.setResponseStatus(SUCCESS);

		return response;

	}

	public RestResponse removeFavRestaurant(final String restaurantId) {
		RestResponse response = new RestResponse();
		favService.removeFavouriteRestaurant(Integer.valueOf(restaurantId));
		response.setResponseStatus(SUCCESS);
		return response;

	}

	
	public List<LocationSuggestions> fetchLocationDetails(final String location) {
		String url = "https://developers.zomato.com/api/v2.1/locations";
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url).queryParam("query", location);

		HttpEntity<String> httpEntity = new HttpEntity<>(createHeader());

		//RestTemplate restTemplate = new RestTemplate();

		ResponseEntity<LocationFetch> result = restbuilder.build().exchange(builder.toUriString(), HttpMethod.GET, httpEntity,
				LocationFetch.class, new Object());
		return result.getBody().getLocationSuggestions();
		

	}
	
	
	
	public FavouriteRestaurant getResDetailById(final int resId) {

		HttpEntity<String> httpEntity = new HttpEntity<>(createHeader());
		StringBuilder serviceEndPointUrl = new StringBuilder();
		FavouriteRestaurant resp= new FavouriteRestaurant();
		
		serviceEndPointUrl.append("https://developers.zomato.com/api/v2.1/restaurant?res_id=").append(resId);
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<FavouriteRestaurant> restuarntDetail = restbuilder.build().exchange(serviceEndPointUrl.toString(),
				HttpMethod.GET, httpEntity, FavouriteRestaurant.class);
		resp=restuarntDetail.getBody();
		
		return resp;

	}

	public FavouriteRestaurantDetail fetchFavList() {

		List<FavouriteRestaurant> favResList = new ArrayList<>();

		List<FavouriteRestEntity> favEntityList = favService.fetchAll();
		FavouriteRestaurantDetail favouriteRestaurantDetail = new FavouriteRestaurantDetail();
		try{
		for (FavouriteRestEntity favoriteEntity : favEntityList) {
			FavouriteRestaurant favouriteRestaurant = getResDetailById(favoriteEntity.getRestaurantId());
			if (null != favouriteRestaurant) {
				favouriteRestaurant.setFavourite(true);
				favResList.add(favouriteRestaurant);
			}

		}
		if(null!=favResList && favResList.size()==0){
			favouriteRestaurantDetail.setStatus("INFO");
			favouriteRestaurantDetail.setMessage("No Records. Please add some Restaurants to your favourite List");
		}
		}
	catch(RestClientException ex){
		favouriteRestaurantDetail.setStatus(ERROR);
		favouriteRestaurantDetail.setMessage(PLEASE_TRY_AGAIN);
	}
		
		
		favouriteRestaurantDetail.setFavouritRestaurantList(favResList);

		return favouriteRestaurantDetail;

	}

	public RestResponse addRestaurantComments(final Comments comments) {
		RestResponse response = new RestResponse();
		favService.addRestaurantComments(Integer.valueOf(comments.getId()), comments.getResComments());
		response.setResponseStatus(SUCCESS);

		return response;

	}

	public FavouriteDetails getAllFavourites() {
		FavouriteDetails favouriteDetails = new FavouriteDetails();
		List<FavouriteRestEntity> favList = favService.fetchAll();
		List<FavouriteResponse> favouriteResponselist = new ArrayList<>();
		for (FavouriteRestEntity entity : favList) {
			FavouriteResponse resp = new FavouriteResponse();
			resp.setRestaurantId(String.valueOf(entity.getRestaurantId()));
			favouriteResponselist.add(resp);
		}
		favouriteDetails.setFavouriteResponse(favouriteResponselist);
		return favouriteDetails;
	}

	
	

	public SearchRestaurantsResponse getDetail(final String entityId,final  String entityType,final  String cityName, final String cusine) {
		String getResturant = "https://developers.zomato.com/api/v2.1/search";
		SearchRestaurantsResponse resp =new SearchRestaurantsResponse(); ;
try{
		HttpEntity<String> httpEntity = new HttpEntity<>(createHeader());

		RestTemplate restTemplate = new RestTemplate();
		UriComponentsBuilder buildURL = UriComponentsBuilder.fromUriString(getResturant)
				.queryParam(ENTITY_ID, entityId).queryParam(ENTITY_TYPE, entityType).queryParam(Q, cusine);
				

		ResponseEntity<SearchRestaurantsResponse> getRestaurantResp = restbuilder.build().exchange(buildURL.toUriString(),
				HttpMethod.GET, httpEntity, SearchRestaurantsResponse.class, new Object());
		 resp=getRestaurantResp.getBody();
}
catch(RestClientException ex){
	resp.setStatus(ERROR);
	resp.setMessage(PLEASE_TRY_AGAIN);
}
		return resp;
	}
	
	private HttpHeaders createHeader(){
		HttpHeaders headers = new HttpHeaders();
		headers.add(USER_KEY, USER_KEY_VALUE);
		return headers;
	}
	

	

}
