package com.stackroute.model;

public class Restaurants {
	
	private Restaurant  restaurant;

	public Restaurant getRestaurant() {
		return restaurant;
	}

	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}

	

}
