package com.stackroute.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CuisinesList {
	@JsonProperty("cuisines")
	private List<Cuisines> cuisines;

	public List<Cuisines> getCuisines() {
		return cuisines;
	}

	public void setCuisines(List<Cuisines> cuisines) {
		this.cuisines = cuisines;
	}	
	
	
	

}
	