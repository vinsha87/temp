package com.stackroute.model;

import java.util.List;

public class CommentsResponse {
	private List<Comments> comments;

	public List<Comments> getComments() {
		return comments;
	}

	public void setComments(List<Comments> comments) {
		this.comments = comments;
	}


}
