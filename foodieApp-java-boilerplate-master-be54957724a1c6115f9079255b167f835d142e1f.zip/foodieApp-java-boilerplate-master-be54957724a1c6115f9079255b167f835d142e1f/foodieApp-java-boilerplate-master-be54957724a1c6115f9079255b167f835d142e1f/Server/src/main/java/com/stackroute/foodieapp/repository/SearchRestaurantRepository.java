package com.stackroute.foodieapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.stackroute.model.RestaurantComments;
@Repository
public interface SearchRestaurantRepository extends JpaRepository<RestaurantComments,Integer>{
	public RestaurantComments findByRestaurantId(Integer restaurantId);
	public List<RestaurantComments> findById(Integer restaurantId);

}
