package com.stackroute.model;

import java.util.List;

public class ReviewResponse {
	
	private List<UserReviews> user_reviews;
	private String status;
	private String message;

	public List<UserReviews> getUser_reviews() {
		return user_reviews;
	}

	public void setUser_reviews(List<UserReviews> user_reviews) {
		this.user_reviews = user_reviews;
	}

	public String getStatus() {
		return status;
	}

	public String getMessage() {
		return message;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	
	
	
	

}
