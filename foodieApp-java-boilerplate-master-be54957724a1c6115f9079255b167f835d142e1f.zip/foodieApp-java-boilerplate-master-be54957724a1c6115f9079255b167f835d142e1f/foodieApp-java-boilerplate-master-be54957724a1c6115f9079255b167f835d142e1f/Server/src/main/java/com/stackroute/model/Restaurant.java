package com.stackroute.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Restaurant {
	
	private String cuisines;
	
	
	private Location location;
	
	@JsonProperty("featured_image")
	private String featuredImage;
	
	private String currency;
	
	@JsonProperty("id")
	private String restaurantId;
	
	private String name;
	@JsonProperty("average_cost_for_two")
	private String averageCostForTwo;
	
	@JsonProperty("user_rating")
	private UserRating userRating;

	

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getCuisines() {
		return cuisines;
	}

	public void setCuisines(String cuisines) {
		this.cuisines = cuisines;
	}


	
	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	

	public String getFeaturedImage() {
		return featuredImage;
	}

	public void setFeaturedImage(String featuredImage) {
		this.featuredImage = featuredImage;
	}

	

	

	

	public String getRestaurantId() {
		return restaurantId;
	}

	public void setRestaurantId(String restaurantId) {
		this.restaurantId = restaurantId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAverageCostForTwo() {
		return averageCostForTwo;
	}

	public void setAverageCostForTwo(String averageCostForTwo) {
		this.averageCostForTwo = averageCostForTwo;
	}

	public UserRating getUserRating() {
		return userRating;
	}

	public void setUserRating(UserRating userRating) {
		this.userRating = userRating;
	}

	

	
	
	
	
}