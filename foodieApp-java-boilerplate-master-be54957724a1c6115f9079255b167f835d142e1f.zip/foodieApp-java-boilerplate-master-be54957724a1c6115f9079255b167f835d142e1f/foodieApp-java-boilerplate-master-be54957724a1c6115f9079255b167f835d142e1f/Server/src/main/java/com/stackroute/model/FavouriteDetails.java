package com.stackroute.model;

import java.util.List;

public class FavouriteDetails {
private List<FavouriteResponse> FavouriteResponse;

public List<FavouriteResponse> getFavouriteResponse() {
	return FavouriteResponse;
}

public void setFavouriteResponse(List<FavouriteResponse> favouriteResponse) {
	FavouriteResponse = favouriteResponse;
}



}
