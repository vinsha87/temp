package com.stackroute.model;

public class Comments {
	
	private String id;
	
	private String resComments;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getResComments() {
		return resComments;
	}

	public void setResComments(String resComments) {
		this.resComments = resComments;
	}

	
	

}
