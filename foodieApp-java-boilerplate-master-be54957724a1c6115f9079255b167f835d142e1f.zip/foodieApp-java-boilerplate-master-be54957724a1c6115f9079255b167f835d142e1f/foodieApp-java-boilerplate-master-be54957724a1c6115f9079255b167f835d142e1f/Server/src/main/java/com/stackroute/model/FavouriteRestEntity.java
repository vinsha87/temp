package com.stackroute.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="favourite_restaurant_details_new",schema="foodieapp")
public class FavouriteRestEntity {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	@Column(name="restaurant_id")
	private Integer restaurantId;
	
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getRestaurantId() {
		return restaurantId;
	}

	public void setRestaurantId(Integer restaurantId) {
		this.restaurantId = restaurantId;
	}
	
	public  FavouriteRestEntity(Integer restaurantId){
		this.restaurantId=restaurantId;
	}
	
	/**
	 * Default constructor
	 */
	public FavouriteRestEntity(){
		
	}

	
	
	
	
}
