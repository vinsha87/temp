package com.stackroute.foodieapp;

import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.stackroute.foodieapp.service.FavouriteManageService;
import com.stackroute.foodieapp.service.FoodieAppService;
import com.stackroute.model.FavouriteDetails;
import com.stackroute.model.FavouriteRestEntity;
import com.stackroute.model.FavouriteRestaurant;
import com.stackroute.model.Location;
import com.stackroute.model.LocationFetch;
import com.stackroute.model.LocationSuggestions;
import com.stackroute.model.Restaurant;
import com.stackroute.model.Restaurants;
import com.stackroute.model.Review;
import com.stackroute.model.ReviewResponse;
import com.stackroute.model.SearchRestaurantsResponse;
import com.stackroute.model.UserReviews;

import junit.framework.Assert;

@RunWith(PowerMockRunner.class)
public class FoodieAppServiceTest {
	
	@InjectMocks 
	private FoodieAppService foodieAppService;
	
	@Mock
	private FavouriteManageService favManageService;
	@Mock
	RestTemplateBuilder restbuilder;
	@Mock
	RestTemplate restTemplate;
	
	@Before
	public void initMethod(){
		MockitoAnnotations.initMocks(this);
		
	}
	
	
	private ReviewResponse getReviewResponse (){
		ReviewResponse reviewResponse= new ReviewResponse();
		List<UserReviews> user_reviews =new ArrayList<>();
		UserReviews userReviews= new UserReviews();
		Review review= new Review();
		review.setReviewText("good");
		review.setRating("4");
		review.setId("R01");
		userReviews.setReview(review);
		user_reviews.add(userReviews);
		reviewResponse.setUser_reviews(user_reviews);
		return reviewResponse;
	}
	
	@Test
	public void testGetReviewPositive(){
		//ReviewResponse
		ReviewResponse reviewResponse=getReviewResponse();
		
		ResponseEntity<ReviewResponse> r= new ResponseEntity(reviewResponse,HttpStatus.OK);
		Mockito.when(restbuilder.build()).thenReturn(restTemplate) ;
		when(restTemplate.exchange(anyString(),eq(HttpMethod.GET),any(ResponseEntity.class),Matchers.<Class<ReviewResponse>>any(),Matchers.<Object>anyVararg())).thenReturn(r);
		ReviewResponse getReviews=foodieAppService.getReviews("A001");
		Assert.assertEquals("good", getReviews.getUser_reviews().get(0).getReview().getReviewText());
		Assert.assertEquals("R01", getReviews.getUser_reviews().get(0).getReview().getId());
		Assert.assertEquals("4", getReviews.getUser_reviews().get(0).getReview().getRating());
	}
	public void testGetReviewNegitive(){
		//ReviewResponse
		ReviewResponse reviewResponse=getReviewResponse();
		
		ResponseEntity<ReviewResponse> r= new ResponseEntity(reviewResponse,HttpStatus.OK);
		Mockito.when(restbuilder.build()).thenReturn(restTemplate) ;
		when(restTemplate.exchange(anyString(),eq(HttpMethod.GET),any(ResponseEntity.class),Matchers.<Class<ReviewResponse>>any(),Matchers.<Object>anyVararg())).thenReturn(r);
		ReviewResponse getReviews=foodieAppService.getReviews("A001");
		Assert.assertNotSame("Bad", getReviews.getUser_reviews().get(0).getReview().getReviewText());
	}
	

	@Test
	public void fetchLocationDetails(){
		List<LocationSuggestions> locationSuggestions = locationSuggest();
		LocationFetch fetch= new LocationFetch();
		fetch.setLocationSuggestions(locationSuggestions);
		
		ResponseEntity<LocationFetch> r= new ResponseEntity(fetch,HttpStatus.OK);
		
		Mockito.when(restbuilder.build()).thenReturn(restTemplate) ;
		when(restTemplate.exchange(anyString(),eq(HttpMethod.GET),any(ResponseEntity.class),Matchers.<Class<LocationFetch>>any(),Matchers.<Object>anyVararg())).thenReturn(r);
		List<LocationSuggestions> listLocation=foodieAppService.fetchLocationDetails("kochi");
		Assert.assertEquals("Kochi", listLocation.get(0).getCityName());
		Assert.assertEquals("City", listLocation.get(0).getEntityType());
		
	}
	

	@Test
	public void fetchLocationDetailsNegetive(){
		List<LocationSuggestions> locationSuggestions = locationSuggestion();
		LocationFetch fetch= new LocationFetch();
		fetch.setLocationSuggestions(locationSuggestions);
		
		ResponseEntity<LocationFetch> r= new ResponseEntity(fetch,HttpStatus.OK);
		
		Mockito.when(restbuilder.build()).thenReturn(restTemplate) ;
		when(restTemplate.exchange(anyString(),eq(HttpMethod.GET),any(ResponseEntity.class),Matchers.<Class<LocationFetch>>any(),Matchers.<Object>anyVararg())).thenReturn(r);
		List<LocationSuggestions> listLocation=foodieAppService.fetchLocationDetails("kochi");
		Assert.assertNotSame("kochi",listLocation.get(0).getCityName());
		
	}
	private SearchRestaurantsResponse getSearchRestaurantsResponse(){
		SearchRestaurantsResponse searchRestaurantsResponse = new SearchRestaurantsResponse();
		List<Restaurants> restaurantsList = new ArrayList<>();
		Restaurants restaurants= new Restaurants();
		Restaurant rest= new Restaurant();
		rest.setName("ABCRest");
		rest.setRestaurantId("001");
		restaurants.setRestaurant(rest);
		restaurantsList.add(restaurants);
		searchRestaurantsResponse.setRestaurants(restaurantsList);
		return searchRestaurantsResponse;
	}
	@Test
	public void testGetDetailPositive(){
		SearchRestaurantsResponse searchRestaurantsResponse = getSearchRestaurantsResponse();
		ResponseEntity<SearchRestaurantsResponse> r= new ResponseEntity(searchRestaurantsResponse,HttpStatus.OK);
		Mockito.when(restbuilder.build()).thenReturn(restTemplate) ;
		when(restTemplate.exchange(anyString(),eq(HttpMethod.GET),any(ResponseEntity.class),Matchers.<Class<SearchRestaurantsResponse>>any(),Matchers.<Object>anyVararg())).thenReturn(r);
		SearchRestaurantsResponse response=foodieAppService.getDetail("001", "city", "kochi", "ice");
		Assert.assertEquals("ABCRest", response.getRestaurants().get(0).getRestaurant().getName());
	}
	
	@Test
	public void testGetDetailNegetive(){
		SearchRestaurantsResponse searchRestaurantsResponse = getSearchRestaurantsResponse();
		ResponseEntity<SearchRestaurantsResponse> r= new ResponseEntity(searchRestaurantsResponse,HttpStatus.OK);
		Mockito.when(restbuilder.build()).thenReturn(restTemplate) ;
		when(restTemplate.exchange(anyString(),eq(HttpMethod.GET),any(ResponseEntity.class),Matchers.<Class<SearchRestaurantsResponse>>any(),Matchers.<Object>anyVararg())).thenReturn(r);
		SearchRestaurantsResponse response=foodieAppService.getDetail("001", "city", "kochi", "ice");
		Assert.assertNotSame("RestCafe", response.getRestaurants().get(0).getRestaurant().getName());
	}
	//FavouriteRestaurant getResDetailById
	
	@Test
	public void testGetResDetailByIdPositive(){
		FavouriteRestaurant favouriteRestaurant= getFavRestaurant();
		int res=1;
		ResponseEntity<FavouriteRestaurant> r= new ResponseEntity(favouriteRestaurant,HttpStatus.OK);
		Mockito.when(restbuilder.build()).thenReturn(restTemplate) ;
		when(restTemplate.exchange(anyString(),eq(HttpMethod.GET),any(ResponseEntity.class),Matchers.<Class<FavouriteRestaurant>>any(),Matchers.<Object>anyVararg())).thenReturn(r);
		FavouriteRestaurant response=foodieAppService.getResDetailById(res);
		Assert.assertEquals("683017", response.getLocation().getZipcode());
		Assert.assertEquals("Kochi", response.getLocation().getCity());
		
	}
	@Test
	public void testGetResDetailByIdNegetive(){
		FavouriteRestaurant favouriteRestaurant= getFavRestaurant();
		int res=1;
		ResponseEntity<FavouriteRestaurant> r= new ResponseEntity(favouriteRestaurant,HttpStatus.OK);
		Mockito.when(restbuilder.build()).thenReturn(restTemplate) ;
		when(restTemplate.exchange(anyString(),eq(HttpMethod.GET),any(ResponseEntity.class),Matchers.<Class<FavouriteRestaurant>>any(),Matchers.<Object>anyVararg())).thenReturn(r);
		FavouriteRestaurant response=foodieAppService.getResDetailById(res);
		Assert.assertNotSame("683015", response.getLocation().getZipcode());
		
	}
	private  FavouriteRestaurant getFavRestaurant(){
		FavouriteRestaurant favouriteRestaurant= new FavouriteRestaurant();
		favouriteRestaurant.setId("001");
		Location loc= new Location();
		loc.setZipcode("683017");
		loc.setAddress("kochi");
		loc.setCity("Kochi");
		favouriteRestaurant.setLocation(loc);
		return favouriteRestaurant;
	}
	
	private List<LocationSuggestions> locationSuggest(){
		
		List<LocationSuggestions> locations=new ArrayList<>();
		LocationSuggestions locationSuggestions=new LocationSuggestions();
		locationSuggestions.setCityName("Kochi");
		locationSuggestions.setEntityId("21");
		locationSuggestions.setEntityType("City");
		locations.add(locationSuggestions);
		return locations;
	}
private List<LocationSuggestions> locationSuggestion(){
		
		List<LocationSuggestions> locations=new ArrayList<>();
		LocationSuggestions locationSuggestions=new LocationSuggestions();
		locationSuggestions.setCityName("Mumbai");
		locations.add(locationSuggestions);
		return locations;
	}
	
	
	
	@Test
	public void addRestaurantComments(){
		doNothing().when(favManageService).addRestaurantComments(anyInt(),anyString());
	}
	
	
	private List<FavouriteRestEntity> getFavRestEntity(){
		List<FavouriteRestEntity> favEntityList = new ArrayList<>();
		FavouriteRestEntity favRestEntity= new FavouriteRestEntity();
		favRestEntity.setRestaurantId(new Integer(901830));
		favEntityList.add(favRestEntity);
		return favEntityList;
	}
	
	@Test
	public void getAllFavourites(){
		when(favManageService.fetchAll()).thenReturn(getFavRestEntity());
		FavouriteDetails details=foodieAppService.getAllFavourites();
		assertTrue(details.getFavouriteResponse().size()>0);
	}
	
	@Test
	public void TestAddFavRestaurant(){
		FavouriteManageService service= mock(FavouriteManageService.class);
		doNothing().when(service).addFavouriteRestaurant(new Integer(01));
		service.add(1,"Add Restaurant");
		verify(service,times(1)).add(1,"Add Restaurant");
		
	}
	
	
	@Test
	public void TestRemoveFavRestaurant(){
		FavouriteManageService service= mock(FavouriteManageService.class);
		doNothing().when(service).removeFavouriteRestaurant(new Integer(01));
		service.add(1,"Removed Restaurant");
		verify(service,times(1)).add(1,"Removed Restaurant");
	}
	
	
	
}
