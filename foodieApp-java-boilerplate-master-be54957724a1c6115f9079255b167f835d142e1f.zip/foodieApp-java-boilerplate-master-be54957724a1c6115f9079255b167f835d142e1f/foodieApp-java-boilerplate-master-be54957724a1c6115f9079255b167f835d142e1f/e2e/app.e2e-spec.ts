

import { AppPage } from './app.po';

describe('web page app', () => {
    let page: AppPage;
    

    beforeEach(() => {
        page = new AppPage();
    });

    it('page contains a link with heading Favourite', () => {
        page.navigatoTo();
        page.getRouterLinkMenus().get(1).getText().then (function(text){
            expect(text).toBe('Favourite');

        });
    });

    it('page contains a link with heading Home', () => {
        page.navigatoTo();
        page.getRouterLinkMenus().get(0).getText().then (function(text){
            expect(text).toBe('Home');

        });
    });

    it('page should contains  Heading restaurant details', () => {
        page.navigatoTo();
        expect(page.getMenuText()).toContain('Restaurant Detals');

    });


    

    it('page contains a search button and should be able to search with user selected Location', () => {
        page.navigatoTo();

        page.getInputTextField().sendKeys('Mumbai');
        page.findSearchButton().click();
        
    });




    it('page contains Restaurant list with label cost for two', () => {
        page.navigatoTo();
        page.getLabel().get(0).getText().then(function (text) {
            expect(text).toContain('Cost of Two');

        });
    });

    it('page contains Restaurant list with button Add favourite', () => {
        page.navigatoTo();
        page.findAddButton().getText().then(function (text) {
            expect(text).toContain('Add favourite');

        });
    });

    it('page contains Restaurant list with button Add favourite and when clicked the label changed to Remove Favourite', () => {
        page.navigatoTo();
        page.findAddButton().getText().then(function (text) {
            expect(text).toContain('Add favourite');
            page.findAddButton().click();
            page.findRemoveButton().getText().then(function (text) {
                expect(text).toContain('Remove favourite');
            });
        });
    });


    it('page navigates to View page when click on any restaurant', () => {
        page.navigatoToS();
        page.getRestaurant().get(0).click();


    });
    it('page navigates to View page which contain heading User Reviews', () => {
        page.navigatoToS();
        page.getRestaurant().get(0).click();
        expect(page.getReviewText()).toContain('User Reviews');

    });
    it('page navigates to View page which contain heading Restaurant Description', () => {
        page.navigatoToS();
        page.getRestaurant().get(0).click();
        expect(page.getPageHeading()).toContain('Restaurant Description');

    });

    it('page navigates to View page which contain a text area where user can add comments', () => {
        page.navigatoToS();
        page.getRestaurant().get(0).click();
        expect(page.getTextArea());

    });

    it('page navigates to View page which contain a text area where user can add comments and save', () => {
        page.navigatoToS();
        page.getRestaurant().get(0).click();
        page.getTextArea().sendKeys('very good');
        page.saveComments().click();
    });



    it('page should contains  Heading Favourite Restaurants', () => {
        page.navigatoToF();
        expect(page.getHeading()).toContain('Favourite Restaurants');

    });



});
