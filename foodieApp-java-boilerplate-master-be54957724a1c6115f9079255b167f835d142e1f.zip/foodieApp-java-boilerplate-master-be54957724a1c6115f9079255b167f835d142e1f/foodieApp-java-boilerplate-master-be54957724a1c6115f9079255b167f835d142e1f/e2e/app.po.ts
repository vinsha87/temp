import { browser, by, element } from 'protractor';

export class AppPage {
    navigatoTo() {
        return browser.get('/');

    }



    getRouterLinkMenus() {
        return element.all(by.css('div nav a'));

    }

    navigatoToSearch() {
        return browser.get('/search');

    }

 

    getMenuText() {

        return element.all(by.tagName('div h2')).getText();
    }


    getInputTextField() {
        return element.all(by.css('#location'));

    }

    getLabel() {
        return element.all(by.css('#cost_For_two'));

    }

    getSearchButton() {
        return element.all(by.css('#search-button'));
    }
    findSearchButton() {
        return element(by.buttonText('Search'));
    }

    findRemoveButton() {
        return element(by.buttonText('Remove favourite'));
    }

    findAddButton() {
        return element(by.buttonText('Add favourite'));
    }

    getRestaurantName() {
        return element.all(by.tagName('div h4 small'));

    }

    navigatoToS() {
        return browser.get('/search');

    }

    getRestaurant() {
        return element.all(by.css('#restaurantCard'));

    }

    getReviewText() {

        return element.all(by.tagName('div h3 small')).getText();
    }

    getPageHeading() {

        return element.all(by.tagName('div h4')).getText();
    }
    getTextArea() {

        return element.all(by.css('#textComments'));
    }
    saveComments() {

        return element.all(by.css('#saveComments'));
    }


    navigatoToF() {
        return browser.get('/favourites');

    }


    getHeading() {

        return element.all(by.tagName('div h4')).getText();
    }


    findRemoveButton1() {
        return element(by.buttonText('Remove favourite'));
    }

}
