# MYSQL_DATABASE should be updated with name of the MySQL schema you have created
$env:MYSQL_DATABASE="foodie_db"

# MYSQL_USER and MYSQL_PASSWORD should be updated with username and password of the MySQL user who can access the schema created
$env:MYSQL_USER="root"
$env:MYSQL_PASSWORD="root"